<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Step 5 Order</label>
    <protected>false</protected>
    <values>
        <field>Active__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>Component__c</field>
        <value xsi:type="xsd:string">Wizard_Fieldset</value>
    </values>
    <values>
        <field>FieldSet__c</field>
        <value xsi:type="xsd:string">CCL_PRF_Order_FieldSet</value>
    </values>
    <values>
        <field>ObjectType__c</field>
        <value xsi:type="xsd:string">PRF__c</value>
    </values>
    <values>
        <field>Order__c</field>
        <value xsi:type="xsd:double">5.0</value>
    </values>
    <values>
        <field>SectionDescription__c</field>
        <value xsi:type="xsd:string">KymriahCommercial_EU_Order</value>
    </values>
    <values>
        <field>WizardConfiguration__c</field>
        <value xsi:type="xsd:string">PRF_KymriahCommercial_US</value>
    </values>
</CustomMetadata>
