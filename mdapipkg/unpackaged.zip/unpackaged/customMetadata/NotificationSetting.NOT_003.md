<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>NOT_003</label>
    <protected>false</protected>
    <values>
        <field>EventKey__c</field>
        <value xsi:type="xsd:string">APH_APPROVED</value>
    </values>
    <values>
        <field>Notifications__c</field>
        <value xsi:type="xsd:string">NOT_003_SMS_EN
NOT_003_EMAIL_EN</value>
    </values>
    <values>
        <field>ObjectType__c</field>
        <value xsi:type="xsd:string">Case</value>
    </values>
    <values>
        <field>RecipientExceptions__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Recipients__c</field>
        <value xsi:type="xsd:string">PLANT_SCM</value>
    </values>
</CustomMetadata>
